package com.example.hubmusique

import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Lecteur natif (ExoPlayer) + MediaSession : notification avec boutons,
 * contrôles écran de verrouillage, Bluetooth/casque, focus audio.
 * La file d'attente est gérée par l'interface web : suivant/précédent lui sont renvoyés.
 */
class PlaybackService : MediaSessionService() {
    companion object { var onSkip: ((Int) -> Unit)? = null }

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        val player = object : ForwardingPlayer(exo) {
            override fun getAvailableCommands(): Player.Commands =
                super.getAvailableCommands().buildUpon()
                    .add(Player.COMMAND_SEEK_TO_NEXT).add(Player.COMMAND_SEEK_TO_PREVIOUS).build()
            override fun isCommandAvailable(command: Int): Boolean =
                command == Player.COMMAND_SEEK_TO_NEXT || command == Player.COMMAND_SEEK_TO_PREVIOUS ||
                    super.isCommandAvailable(command)
            override fun seekToNext() { onSkip?.invoke(1) }
            override fun seekToPrevious() { onSkip?.invoke(-1) }
            override fun seekToNextMediaItem() { onSkip?.invoke(1) }
            override fun seekToPreviousMediaItem() { onSkip?.invoke(-1) }
        }
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) { pauseAllPlayersAndStopSelf() }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
