package com.example.hubmusique

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { web.evaluateJavascript("window.onAudioPermission&&onAudioPermission()", null) }

    /** Envoie la position / l'état du lecteur natif à l'interface web. */
    private fun push() {
        val c = controller ?: return
        val dur = if (c.duration == C.TIME_UNSET) 0.0 else c.duration / 1000.0
        web.evaluateJavascript("window.nativeState&&nativeState(${c.currentPosition / 1000.0},$dur,${c.isPlaying})", null)
    }
    private val ticker = object : Runnable {
        override fun run() { push(); handler.postDelayed(this, 500) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(r.url)
            }
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("https://appassets.androidplatform.net/assets/music.html")
        }
        setContentView(web)

        // Connexion au service de lecture
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) = push()
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED) web.evaluateJavascript("window.nativeEnded&&nativeEnded()", null)
                }
            })
        }, ContextCompat.getMainExecutor(this))

        // Boutons suivant/précédent de la notification → file d'attente de l'interface
        PlaybackService.onSkip = { d -> runOnUiThread { web.evaluateJavascript("step($d)", null) } }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(function(){var p=document.querySelector('.page.show');if(p){p.classList.remove('show');return 1}return 0})()") {
                    if (it != "1") moveTaskToBack(true)
                }
            }
        })
    }

    override fun onStart() { super.onStart(); handler.post(ticker) }
    override fun onStop() { handler.removeCallbacks(ticker); super.onStop() }

    override fun onDestroy() {
        PlaybackService.onSkip = null
        controller?.release()
        stopService(Intent(this, PlaybackService::class.java))
        web.destroy()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface fun requestAudioPermission() = runOnUiThread {
            val p = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            permLauncher.launch(p)
        }

        @JavascriptInterface fun getTracks(): String {
            val out = JSONArray()
            val cols = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE)
            try {
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols,
                    "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.DISPLAY_NAME} ASC"
                )?.use { c ->
                    while (c.moveToNext()) out.put(JSONObject().put("id", c.getLong(0)).put("name", c.getString(1)).put("size", c.getLong(2)))
                }
            } catch (_: SecurityException) { }
            return out.toString()
        }

        @JavascriptInterface fun playTrack(id: String, title: String) = runOnUiThread {
            val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toLong())
            val item = MediaItem.Builder().setUri(uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist("HUB MUSIQUE").build()).build()
            controller?.run { setMediaItem(item); prepare(); play() }
        }
        @JavascriptInterface fun resume() = runOnUiThread { controller?.play() }
        @JavascriptInterface fun pause() = runOnUiThread { controller?.pause() }
        @JavascriptInterface fun stop() = runOnUiThread { controller?.run { stop(); clearMediaItems() } }
        @JavascriptInterface fun seekTo(ms: Double) = runOnUiThread { controller?.seekTo(ms.toLong()) }
        @JavascriptInterface fun openUrl(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }
}
